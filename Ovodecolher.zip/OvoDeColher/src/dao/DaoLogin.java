/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controle.ControleLogin;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Login;
import model.Vendedor;

/**
 *
 * @author biaab
 */
public class DaoLogin {
    
    public boolean cadastrarLogin(Login login){
       
        try(Connection conector= new DaoConexao().getConnection()){
           
            String sql = "SELECT Usuario, Senha FROM vendedor WHERE Usuario = '"+login.getUsuario()+"' "
                    + "AND Senha = '"+login.getSenha()+"' ";
            PreparedStatement stm = conector.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            Login login1 = new Login();
            Vendedor vendedor = new Vendedor();
            
            while(rs.next()){
                login1.setUsuario(rs.getString("Usuario"));
               login1.setSenha(rs.getString("Senha"));
            }
            if(login1.getUsuario().equals("")  && login1.getSenha().equals("")){
                String sql1 = "SELECT Usuario, Senha FROM vendedor WHERE nome = '"+login.getUsuario()+"' "
                    + "AND senha = '"+login.getSenha()+"' ";
              stm = conector.prepareStatement(sql1);
                rs = stm.executeQuery();
                while(rs.next()){
                   login1.setUsuario(rs.getString("nome"));
                    login1.setSenha(rs.getString("senha"));
            }
            }
           
           
            ControleLogin loginC = new ControleLogin();
           return loginC.verificarLogin(login, login1);
           
           
        }catch(SQLException e){
            throw new RuntimeException (e);
        }
    
}

    public void login(Login login) {
        }
}
