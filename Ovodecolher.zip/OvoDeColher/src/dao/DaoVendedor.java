
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import model.Vendedor;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoVendedor {
     public void cadastrarVendedor(Vendedor vend ) throws DaoException{
        String sql = "insert into vendedor (NomeVedendor, DataNascimentoVedendor, TelefoneVedendor, Usuario, Senha) value (?, ?, ?, ?, ?)";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        java.sql.Date dt_sql = null ;
        SimpleDateFormat formatarDate = new SimpleDateFormat("dd/MM/yyyy");
        Date data;
         try {
             data = formatarDate.parse(vend.getDataNascimentoVedendor());
              dt_sql = new java.sql.Date(data.getTime());
         } catch (ParseException ex) {
             Logger.getLogger(DaoVendedor.class.getName()).log(Level.SEVERE, null, ex);
         }

        try{
              
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, vend.getNomeVedendor());
            pStatement.setDate(2, dt_sql);
            pStatement.setInt(3, vend.getTelefoneVedendor());
            pStatement.setString(4, vend.getUsuario());
            pStatement.setString(5, vend.getSenha());
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar vendedor! " + e);
            
        } finally {
            
            
            
        } try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoException("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoException("Erro ao fechar a conexão! " + e);
        }
    }
    
   public boolean deletarVendedor(Vendedor vend ) throws DaoException{
        
        PreparedStatement pStatement = null;
        Connection connection = null;
       
        try{
           String sql = "delete from vendedor where NomeVedendor = '"+vend.getNomeVedendor()+"' and Usuario = '"+vend.getUsuario()+"' and Senha = '"+vend.getSenha()+"'";
           connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql);
                  
            pStatement.executeUpdate();   
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar vendedor! " + e);
            
        } finally {
            
            
            
        } try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoException("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoException("Erro ao fechar a conexão! " + e);
        } return true;
    }
}
    
    



