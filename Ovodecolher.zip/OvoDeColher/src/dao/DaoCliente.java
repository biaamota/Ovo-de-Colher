
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Cliente;

public class DaoCliente {
     public void cadastrarCliente(Cliente cli ) throws DaoException{
        String sql = "insert into cliente (NomeCliente, DataNascimentoCli, TelefoneCliente, TipoCliente, Rua, CPF_CNPJ, Bairro, NumCasa, CEP, UF) value (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
         try{
              
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, cli.getNomeCliente());
            pStatement.setString(2, cli.getDataNascimentoCli());
            pStatement.setInt(3, cli.getTelefoneCliente());
            pStatement.setInt(4, cli.getTipoCliente());
            pStatement.setString(5, cli.getRua());
            pStatement.setString(6, cli.getCPF_CNPJ());
            pStatement.setString(7, cli.getBairro());
            pStatement.setInt(8, cli.getNumCasa());
            pStatement.setString(9, cli.getCEP());
            pStatement.setString(10, cli.getUF());
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar cliente! " + e);
            
        } finally {
            
            
            
        } try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoException("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoException("Erro ao fechar a conexão! " + e);
        }
    }
    
    public void alterarCliente(Cliente clien ) throws DaoException{
        String sql = "update cliente set NomeCliente = ?, TelefoneCliente = ?, TipoCliente = ? "
                + "WHERE idcliente = 2";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
         try{
              
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, clien.getNomeCliente());
            pStatement.setInt(2, clien.getTelefoneCliente());
            pStatement.setInt(3, clien.getTipoCliente());
   
            
            pStatement.executeUpdate();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao alterar os dados do Cliente! " + e);
            
        } finally {
            
            
            
        } try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoException("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoException("Erro ao fechar a conexão! " + e);
        }
    }
}
    
    



