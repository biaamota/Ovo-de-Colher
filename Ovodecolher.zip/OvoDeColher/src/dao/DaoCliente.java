
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Cliente;


public class DaoCliente {
     public void cadastrarCliente(Cliente cli ) throws DaoException{
        String sql = "insert into cliente (NomeCliente, DataNascimentoCli, TelefoneCliente, TipoCliente, Rua, CPF_CNPJ, Bairro, NumCasa, CEP, UF) value (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
         try{
              
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, cli.getNomeCliente());
            pStatement.setString(2, cli.getDataNascimentoCli());
            pStatement.setInt(3, cli.getTelefoneCliente());
            pStatement.setInt(4, cli.getTipoCliente());
            pStatement.setString(5, cli.getRua());
            pStatement.setString(6, cli.getCPF_CNPJ());
            pStatement.setString(7, cli.getBairro());
            pStatement.setInt(8, cli.getNumCasa());
            pStatement.setString(9, cli.getCEP());
            pStatement.setString(10, cli.getUF());
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar cliente! " + e);
            
        } finally {
            
            
            
        } try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoException("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoException("Erro ao fechar a conexão! " + e);
        }
    }
    
    public boolean deletarCliente(Cliente cli ) throws DaoException{
        
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        java.sql.Date dt_sql = null ;
        SimpleDateFormat formatarDate = new SimpleDateFormat("yyyy/MM/dd");
        Date data;
         try {
             data = formatarDate.parse(cli.getDataNascimentoCli());
              dt_sql = new java.sql.Date(data.getTime());
         } catch (ParseException ex) {
             Logger.getLogger(DaoCliente.class.getName()).log(Level.SEVERE, null, ex);
         }
       
        try{
           String sql = "delete from cliente where NomeCliente = '"+cli.getNomeCliente()+"' and DataNascimentoCli = '"+cli.getDataNascimentoCli()+"' and CPF_CNPJ = '"+cli.getCPF_CNPJ()+"'";
           connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql);
                  
            pStatement.executeUpdate();   
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar vendedor! " + e);
            
        } finally {
            
            
            
        } try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoException("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoException("Erro ao fechar a conexão! " + e);
        } return true;
    }
    
    public ArrayList<Cliente> consultarCliente(Cliente cliente){
        ArrayList<Cliente> cliente1 = new ArrayList<Cliente>();
        
        try(Connection co = new DaoConexao().getConnection()){
            String sql = "SELECT NomeCliente, CPF_CNPJ, Rua"
                    + " FROM cliente WHERE NomeCliente ='"+cliente.getNomeCliente()+"' AND CPF_CNPJ='"+cliente.getCPF_CNPJ()+"' ";
            PreparedStatement stm = co.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            
            while(rs.next()){
                Cliente cliente2 = new Cliente();
                cliente2.setNomeCliente(rs.getString("NomeCliente"));
                cliente2.setCPF_CNPJ(rs.getString("CPF_CNPJ"));
                cliente2.setRua(rs.getString("Rua"));
                cliente1.add(cliente2);
            }
            
        }catch(SQLException e) {
            throw new RuntimeException(e);
        }
        
        
        
        return cliente1;
    }
    
    public void excluirCliente(Cliente cliente){
        
        try(Connection co = new DaoConexao().getConnection()){
            String sql = "DELETE FROM cliente WHERE NomeCliente ='"+cliente.getNomeCliente()+"' AND CPF_CNPJ ='"+cliente.getCPF_CNPJ()+"' ";
            PreparedStatement stmt = co.prepareStatement(sql);
            stmt.execute();
            stmt.close();
            
            
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
    
    public void alterarCliente(Cliente cli ) throws DaoException{
        String sql = "UPDATE cliente SET Idcliente =? ,TelefoneCliente =? ,TipoCliente =? ,NomeCliente =? ,Rua =? ,NumCasa =? ,Bairro =? ,CEP =? ,UF =? ,CPF_CNPJ =? ,DataNascimentoCli =?  WHERE "+cli.getCPF_CNPJ()+"";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
         try{
              
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, cli.getNomeCliente());
            pStatement.setString(2, cli.getDataNascimentoCli());
            pStatement.setInt(3, cli.getTelefoneCliente());
            pStatement.setInt(4, cli.getTipoCliente());
            pStatement.setString(5, cli.getRua());
            pStatement.setString(6, cli.getCPF_CNPJ());
            pStatement.setString(7, cli.getBairro());
            pStatement.setInt(8, cli.getNumCasa());
            pStatement.setString(9, cli.getCEP());
            pStatement.setString(10, cli.getUF());
            pStatement.executeUpdate();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao alterar cliente! " + e);
            
        } finally {
            
            
            
        } try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoException("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoException("Erro ao fechar a conexão! " + e);
        }
    }
}
    
    



