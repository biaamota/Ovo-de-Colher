
package dao;

public class DaoException extends Exception {
    public DaoException(String mensagem){
        super(mensagem);
}
}