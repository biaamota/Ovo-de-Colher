package dao;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Login;
import model.Pedido;

public class DaoPedido {

    public void cadastrarPedido(Pedido pedi) throws DaoException {

        String sql2 = "insert into produto ( SaborRecheio, Tamanho, SaborCasca, ValorProduto) value (?, ?, ?, ?)";

        PreparedStatement pStatement = null;
        Connection connection = null;

        java.sql.Date dt_sql = null;
        SimpleDateFormat formatarDate = new SimpleDateFormat("dd/MM/yyyy");
        Date data;
        ResultSet rs = null;

        //produto 
        try {

            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql2, Statement.RETURN_GENERATED_KEYS);

            pStatement.setString(1, pedi.getSaborRecheio());
            pStatement.setString(2, pedi.getTamanho());
            pStatement.setString(3, pedi.getSaborCasca());
            pStatement.setFloat(4, pedi.getValorProduto());
            pStatement.executeUpdate();

            // pegando id do item que foi inserido
            rs = pStatement.getGeneratedKeys();
            if (rs != null && rs.next()) {
                pedi.setIdProduto(rs.getInt(1));
            }
        } catch (SQLException e) {
            throw new DaoException("Erro ao cadastrar produto! " + e);

        } finally {
        }

        //buscar idCliente
        try (Connection con = new DaoConexao().getConnection()) {

            String sql5 = "SELECT Idcliente FROM cliente WHERE CPF_CNPJ = '" + pedi.getCpf() + "' ";
            pStatement = con.prepareStatement(sql5);
            ResultSet rs1 = pStatement.executeQuery();
            while (rs1.next()) {
                pedi.setIdcliente(rs1.getInt("Idcliente"));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        try {
            data = formatarDate.parse(pedi.getDataEntrega());
            dt_sql = new java.sql.Date(data.getTime());
        } catch (ParseException ex) {
            Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);
        }

        String sql = "insert into pedido ( DataEntrega, ValorTotal, Idcliente, Idvendedor) VALUE( ?, ?, ?,?)";

        try {
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            pStatement.setDate(1, dt_sql);
            pStatement.setFloat(2, pedi.getValorTotal());
            pStatement.setInt(3, pedi.getIdcliente());
            pStatement.setInt(4, Login.getIdLoginVendedor());

            pStatement.execute();

            rs = pStatement.getGeneratedKeys();
            if (rs != null && rs.next()) {
                pedi.setIdPedido(rs.getInt(1));
            }

        } catch (SQLException e) {
            throw new DaoException("Erro ao cadastrar pedido! " + e);

        } finally {
        }
        //

        String sql1 = "insert into item ( ValorIntem, Quantidade,Idpedido, Idproduto) value (?, ?,?,?)";

        try {
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql1);

            pStatement.setFloat(1, pedi.getValorIntem());
            pStatement.setInt(2, pedi.getQuantidade());
            pStatement.setInt(3, pedi.getIdPedido());
            pStatement.setInt(4, pedi.getIdProduto());
            pStatement.execute();

        } catch (SQLException e) {
            throw new DaoException("Erro ao cadastrar item! " + e);

        } finally {
        }

        try {
            if (pStatement != null) {
                pStatement.close();
            }
        } catch (SQLException e) {
            throw new DaoException("Erro ao fechar o Statement! " + e);

        }
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            throw new DaoException("Erro ao fechar a conexão! " + e);
        }
    }

    public void alterarPedido(Pedido pedi) throws DaoException {
        String sql = "update pedido set DataEntrega = ?, ValorTotal = ? where Idvendedor = 7";
        String sql1 = " update item set ValorIntem = ?, Quantidade =? where IdItem = 7";
        String sql2 = "update produto set SaborRecheio = ?, Tamanho = ?, SaborCasca =?, ValorProduto = ? where IdProduto = 7";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        java.sql.Date dt_sql = null ;
        SimpleDateFormat formatarDate = new SimpleDateFormat("dd/MM/yyyy");
        Date data;
         try {
             data = formatarDate.parse(pedi.getDataEntrega());
              dt_sql = new java.sql.Date(data.getTime());
         } catch (ParseException ex) {
             Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);}

        try{ 
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql);
            
            pStatement.setDate(1, dt_sql);
            pStatement.setFloat(2, pedi.getValorTotal());
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar pedido! " + e);
            
        } finally {}
        //
        
         try{ 
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql1);

            pStatement.setFloat(1, pedi.getValorIntem());
            pStatement.setInt(2, pedi.getQuantidade());
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar item! " + e);
            
        } finally {}
        
        //
        
         try{ 
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql2);
            
           pStatement.setString(1, pedi.getSaborRecheio());           
            pStatement.setString(2, pedi.getTamanho());
            pStatement.setString(3, pedi.getSaborCasca());
            pStatement.setFloat(4, pedi.getValorProduto());
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar produto! " + e);
            
        } finally {}
        
        //
        try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoException("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoException("Erro ao fechar a conexão! " + e);
        }
    }
}
