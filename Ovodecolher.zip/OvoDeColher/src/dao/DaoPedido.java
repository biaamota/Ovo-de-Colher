
package dao;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Pedido;

public class DaoPedido {
    
     public void cadastrarPedido(Pedido pedi ) throws DaoException{
        String sql = "insert into pedido ( DataEntrega, ValorTotal, Idcliente, Idvendedor ) value ( ?, ?, 2,1)";
        String sql1 = "insert into item ( ValorIntem, Quantidade,Idpedido, Idproduto) value (?, ?,5,6)";
        String sql2 = "insert into produto ( SaborRecheio, Tamanho, SaborCasca, ValorProduto) value (?, ?, ?, ?)";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        java.sql.Date dt_sql = null ;
        SimpleDateFormat formatarDate = new SimpleDateFormat("dd/MM/yyyy");
        Date data;
         
         try {
             data = formatarDate.parse(pedi.getDataEntrega());
              dt_sql = new java.sql.Date(data.getTime());
         } catch (ParseException ex) {
             Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);}

             
         
        try{ 
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql);
            
            pStatement.setDate(1, dt_sql);
            pStatement.setFloat(2, pedi.getValorTotal());            
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar pedido! " + e);
            
        } finally {}
        //
        
         try{ 
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql1);

            pStatement.setFloat(1, pedi.getValorIntem());
            pStatement.setInt(2, pedi.getQuantidade());
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar item! " + e);
            
        } finally {}
        
        //
        
        try{ 
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql2);
            
            pStatement.setString(1, pedi.getSaborRecheio());           
            pStatement.setString(2, pedi.getTamanho());
            pStatement.setString(3, pedi.getSaborCasca());
            pStatement.setFloat(4, pedi.getValorProduto());
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar produto! " + e);
            
        } finally {}
        
        //
        try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoException("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoException("Erro ao fechar a conexão! " + e);
        }
    }
    
      public void alterarPedido(Pedido pedi ) throws DaoException{
        String sql = "update pedido set DataEntrega = ?, ValorTotal = ? where Idvendedor = 1";
        String sql1 = " update item set ValorIntem = ?, Quantidade =? where IdItem = 3";
        String sql2 = "update produto set SaborRecheio = ?, Tamanho = ?, SaborCasca =?, ValorProduto = ? where IdProduto = 5";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        java.sql.Date dt_sql = null ;
        SimpleDateFormat formatarDate = new SimpleDateFormat("dd/MM/yyyy");
        Date data;
         try {
             data = formatarDate.parse(pedi.getDataEntrega());
              dt_sql = new java.sql.Date(data.getTime());
         } catch (ParseException ex) {
             Logger.getLogger(DaoPedido.class.getName()).log(Level.SEVERE, null, ex);}

        try{ 
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql);
            
            pStatement.setDate(1, dt_sql);
            pStatement.setFloat(2, pedi.getValorTotal());
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar pedido! " + e);
            
        } finally {}
        //
        
         try{ 
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql1);

            pStatement.setFloat(1, pedi.getValorIntem());
            pStatement.setInt(2, pedi.getQuantidade());
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar item! " + e);
            
        } finally {}
        
        //
        
         try{ 
            connection = new DaoConexao().getConnection();
            pStatement = connection.prepareStatement(sql2);
            
           pStatement.setString(1, pedi.getSaborRecheio());           
            pStatement.setString(2, pedi.getTamanho());
            pStatement.setString(3, pedi.getSaborCasca());
            pStatement.setFloat(4, pedi.getValorProduto());
            pStatement.execute();
            
        }catch(SQLException e){
            throw new DaoException("Erro ao cadastrar produto! " + e);
            
        } finally {}
        
        //
        try {
            if(pStatement != null) {pStatement.close();}
        } catch(SQLException e){
            throw new DaoException("Erro ao fechar o Statement! " + e);
            
            
        } try {
            if (connection != null) {connection.close();}
        } catch(SQLException e) {
            throw new DaoException("Erro ao fechar a conexão! " + e);
        }
    }
}
    
    



