/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import dao.DaoException;
import dao.DaoPedido;
import model.Pedido;


/**
 *
 * @author biaab
 */
public class ControlePedido {
      
 public boolean cadastrarPedido( String Tamanho, String Quantidade, String ValorProduto, String SaborRecheio,String SaborCasca, String DataEntrega, String ValorIntem, String ValorTotal) throws DaoException {
        
    if ( Tamanho != null && Tamanho.length() > 0 && Quantidade != null && Quantidade.length() > 0 && ValorProduto != null && ValorProduto.length() > 0 &&
		SaborRecheio != null && SaborRecheio.length() > 0 && SaborCasca != null && SaborCasca.length() > 0 &&
		DataEntrega != null && DataEntrega.length() > 0 && ValorIntem != null && ValorIntem.length() > 0 && ValorTotal != null && ValorTotal.length() > 0 ) {
            
            Pedido pedi = new Pedido(Tamanho, Integer.parseInt(Quantidade), Float.parseFloat(ValorProduto), SaborRecheio, SaborCasca, DataEntrega, Integer.parseInt(ValorIntem), Integer.parseInt(ValorTotal));
       
            pedi.setTamanho(Tamanho);
            pedi.setQuantidade(pedi.getQuantidade());
            pedi.setValorProduto(pedi.getValorProduto());
            pedi.setSaborRecheio(SaborRecheio);
            pedi.setSaborCasca(SaborCasca);
            pedi.setDataEntrega(DataEntrega);
            pedi.setValorIntem(pedi.getValorIntem());
            pedi.setValorTotal(pedi.getValorTotal());
            
          DaoPedido dao = new DaoPedido();
          dao.cadastrarPedido(pedi);
            
            return true;

        } else {
            return false;
        }
    }

    public boolean alterarPedido(String Tamanho, String Quantidade, String ValorProduto, String SaborRecheio,String SaborCasca, String DataEntrega, String ValorIntem, String ValorTotal) throws DaoException {
        if ( Tamanho != null && Tamanho.length() > 0 && Quantidade != null && Quantidade.length() > 0 && ValorProduto != null && ValorProduto.length() > 0 &&
		SaborRecheio != null && SaborRecheio.length() > 0 && SaborCasca != null && SaborCasca.length() > 0 &&
		DataEntrega != null && DataEntrega.length() > 0 && ValorIntem != null && ValorIntem.length() > 0 && ValorTotal != null && ValorTotal.length() > 0 ) {
            
            Pedido pedi = new Pedido(Tamanho, Integer.parseInt(Quantidade), Float.parseFloat(ValorProduto), SaborRecheio, SaborCasca, DataEntrega, Integer.parseInt(ValorIntem), Integer.parseInt(ValorTotal));
        
            pedi.setTamanho(Tamanho);
            pedi.setQuantidade(pedi.getQuantidade());
            pedi.setValorProduto(pedi.getValorProduto());
            pedi.setSaborRecheio(SaborRecheio);
            pedi.setSaborCasca(SaborCasca);
            pedi.setDataEntrega(DataEntrega);
            pedi.setValorIntem(pedi.getValorIntem());
            pedi.setValorTotal(pedi.getValorTotal());
            
          DaoPedido dao = new DaoPedido();
          dao.alterarPedido(pedi);
          
            return true;
        }

        return false;
    } 
}
