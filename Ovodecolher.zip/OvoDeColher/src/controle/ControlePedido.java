
package controle;

import dao.DaoException;
import dao.DaoPedido;
import model.Pedido;

/**
 *
 * @author biaab
 */
public class ControlePedido {

    public boolean cadastrarPedido(String CPF, String Tamanho, String Quantidade, String ValorProduto, String SaborRecheio, String SaborCasca, String DataEntrega, String ValorIntem, String ValorTotal) throws DaoException {

        if (CPF != null && CPF.length() > 0 && Tamanho != null && Tamanho.length() > 0 && Quantidade != null && Quantidade.length() > 0 && ValorProduto != null && ValorProduto.length() > 0
                && SaborRecheio != null && SaborRecheio.length() > 0 && SaborCasca != null && SaborCasca.length() > 0
                && DataEntrega != null && DataEntrega.length() > 0 && ValorIntem != null && ValorIntem.length() > 0 && ValorTotal != null && ValorTotal.length() > 0) {

            Pedido pedi = new Pedido(CPF, Tamanho, Integer.parseInt(Quantidade), Float.parseFloat(ValorProduto), SaborRecheio, SaborCasca, DataEntrega, Float.parseFloat(ValorIntem), Float.parseFloat(ValorTotal));

            DaoPedido dao = new DaoPedido();
            dao.cadastrarPedido(pedi);

            return true;

        } else {
            return false;
        }
    }

    public boolean alterarPedido(String CPF, String Tamanho, String Quantidade, String ValorProduto, String SaborRecheio, String SaborCasca, String DataEntrega, String ValorIntem, String ValorTotal) throws DaoException {
        if (Tamanho != null && Tamanho.length() > 0 && Quantidade != null && Quantidade.length() > 0 && ValorProduto != null && ValorProduto.length() > 0
                && SaborRecheio != null && SaborRecheio.length() > 0 && SaborCasca != null && SaborCasca.length() > 0
                && DataEntrega != null && DataEntrega.length() > 0 && ValorIntem != null && ValorIntem.length() > 0 && ValorTotal != null && ValorTotal.length() > 0) {

            Pedido pedi = new Pedido(CPF, Tamanho, Integer.parseInt(Quantidade), Float.parseFloat(ValorProduto), SaborRecheio, SaborCasca, DataEntrega, Float.parseFloat(ValorIntem), Float.parseFloat(ValorTotal));

            pedi.setTamanho(Tamanho);
            pedi.setQuantidade(pedi.getQuantidade());
            pedi.setValorProduto(pedi.getValorProduto());
            pedi.setSaborRecheio(SaborRecheio);
            pedi.setSaborCasca(SaborCasca);
            pedi.setDataEntrega(DataEntrega);
            pedi.setValorIntem(pedi.getValorIntem());
            pedi.setValorTotal(pedi.getValorTotal());

            DaoPedido dao = new DaoPedido();
            dao.alterarPedido(pedi);

            return true;
        }

        return false;
    }
}
