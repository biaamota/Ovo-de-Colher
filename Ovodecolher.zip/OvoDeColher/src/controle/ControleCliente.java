package controle;

import dao.DaoCliente;
import model.Cliente;
import dao.DaoException;

public class ControleCliente {

    public boolean cadastrarCliente( String NomeCliente, String DataNascimentoCli, String TelefoneCliente, String TipoCliente, String Rua, String CPF_CNPJ, String Bairro, String NumCasa, String CEP, String UF) throws DaoException {
        if ( NomeCliente != null && NomeCliente.length() > 0 && DataNascimentoCli != null && DataNascimentoCli.length() > 0 && TelefoneCliente != null && TelefoneCliente.length() > 0 &&
		TipoCliente != null && TipoCliente.length() > 0 && Rua != null && Rua.length() > 0 && CPF_CNPJ != null && CPF_CNPJ.length() > 0 && Bairro != null && Bairro.length() > 0 &&
		NumCasa != null && NumCasa.length() > 0 && CEP != null && CEP.length() > 0 && UF != null && UF.length() > 0) {
            
            String dia = DataNascimentoCli.substring(0, 2);
             String mes = DataNascimentoCli.substring(3,5);
             String ano = DataNascimentoCli.substring(6);
            
            
             String data = ano+"-"+mes+"-"+dia;
            
            Cliente cli = new Cliente(Integer.parseInt(TelefoneCliente), Integer.parseInt(TipoCliente), NomeCliente, Rua, Integer.parseInt(NumCasa), Bairro, CEP, UF, CPF_CNPJ, data);
            DaoCliente dao = new DaoCliente();
            dao.cadastrarCliente(cli);
            return true;

        } else {
            return false;
        }
    }
    
   public void excluirCliente(Cliente cliente){
       DaoCliente dao = new DaoCliente();
       dao.excluirCliente(cliente);
   }
    
      public void alterarCliente(Cliente cliente){
       DaoCliente dao = new DaoCliente();
       dao.excluirCliente(cliente);
   }

    public boolean alterarCliente(String Nome, String DataNascimentoCli, String Telefone, String TipoCliente, String Rua, String CPFCNPJ, String Bairro, String NumeroCasa, String CEP, String UF) throws DaoException {
        return true;
     
    }

    
   
}

