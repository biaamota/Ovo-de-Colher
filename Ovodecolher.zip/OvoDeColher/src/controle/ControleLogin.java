/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;
import dao.DaoLogin;
import javax.swing.JOptionPane;
import model.Login;
import view.TelaPrincipal;

/**
 *
 * @author biaab
 */
public class ControleLogin {
    public boolean cadastrarLogin(Login login){
        
        DaoLogin dao = new DaoLogin();
      return  dao.cadastrarLogin(login);
    }
    
    public boolean verificarLogin(Login login, Login login1){
        if(login.getUsuario().equals(login1.getUsuario()) && login.getSenha().equals(login1.getSenha())){
            JOptionPane.showMessageDialog(null, "seja bem vindo " + login.getUsuario());
            TelaPrincipal telp = new TelaPrincipal();
            telp.setVisible(true);
        //    telp.setarLogin(login1);
            return true;
            
        }else{
            JOptionPane.showMessageDialog(null, "Acesso Negado!");
            return false;
        }
        
    }
}

