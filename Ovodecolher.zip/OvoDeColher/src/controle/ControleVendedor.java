/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import dao.DaoVendedor;
import dao.DaoException;
import model.Vendedor;

/**
 *
 * @author biaab
 */
public class ControleVendedor {
     
 public boolean cadastrarVendedor( String NomeVedendor, String DataNascimentoVedendor, String TelefoneVedendor, String Usuario, String Senha) throws DaoException {
        if ( NomeVedendor != null && NomeVedendor.length() > 0 && DataNascimentoVedendor != null && DataNascimentoVedendor.length() > 0 && TelefoneVedendor != null && TelefoneVedendor.length() > 0 &&
		Usuario != null && Usuario.length() > 0 && Senha != null && Senha.length() > 0 ) {
       
            
            Vendedor vend = new Vendedor(NomeVedendor, DataNascimentoVedendor, Integer.parseInt(TelefoneVedendor), Usuario, Senha);
            vend.setNomeVedendor(NomeVedendor);
            vend.setDataNascimentoVedendor(DataNascimentoVedendor); 
            vend.setTelefoneVedendor( Integer.parseInt(TelefoneVedendor));
            vend.setUsuario(Usuario);
            vend.setSenha(Senha);
            DaoVendedor dao = new DaoVendedor();
            dao.cadastrarVendedor(vend);
            return true;

        } else {
            return false;
        }
    }

  /* public boolean deletarVendedor( String NomeVedendor, String Usuario, String Senha) throws DaoException {
        if ( NomeVedendor != null && NomeVedendor.length() > 0 &&
		Usuario != null && Usuario.length() > 0 && Senha != null && Senha.length() > 0 ) {
       
            
            Vendedor vend = new Vendedor(NomeVedendor, Usuario, Senha);
            vend.setNomeVedendor(NomeVedendor);
            vend.setUsuario(Usuario);
            vend.setSenha(Senha);
            DaoVendedor dao = new DaoVendedor();
            dao.cadastrarVendedor(vend);
            return true;

        } else {
            return false;
        } 
   
   } */
}
