
package model;
public class Pedido {
    private int IdPedido;	
    private String DataEntrega;
    private float ValorTotal;
    private  int IdItem;		
    private float ValorIntem; 
    private int	Quantidade;
    private int	Idcliente;	
    private int IdProduto;
    private int Idvendedor;
    private String SaborRecheio;
    private String Tamanho;
    private String SaborCasca;
    private float ValorProduto;

     public Pedido() {
    
}
    
    public Pedido(String Tamanho, int Quantidade, float ValorProduto, String SaborRecheio, String SaborCasca, String DataEntrega, float ValorIntem, float ValorTotal) {
        this.DataEntrega = DataEntrega;
        this.ValorTotal = ValorTotal;
        this.ValorIntem = ValorIntem;
        this.Quantidade = Quantidade;
        this.SaborRecheio = SaborRecheio;
        this.Tamanho = Tamanho;
        this.SaborCasca = SaborCasca;
        this.ValorProduto = ValorProduto;
}

    public int getIdvendedor() {
        return Idvendedor;
    }

    public void setIdvendedor(int Idvendedor) {
        this.Idvendedor = Idvendedor;
    }

    
    public void cadastrarPedido(Pedido pedi) {
    
}
    public int getIdProduto() {
        return IdProduto;
    }

    public void setIdProduto(int IdProduto) {
        this.IdProduto = IdProduto;
    }
      
    public int getIdItem() {
        return IdItem;
    }

    public void setIdItem(int IdItem) {
        this.IdItem = IdItem;
    }

    public float getValorIntem() {
        return ValorIntem;
    }

    public void setValorIntem(float ValorIntem) {
        this.ValorIntem = ValorIntem;
    }

    public int getQuantidade() {
        return Quantidade;
    }

    public void setQuantidade(int Quantidade) {
        this.Quantidade = Quantidade;
    }

    public String getSaborRecheio() {
        return SaborRecheio;
    }

    public void setSaborRecheio(String SaborRecheio) {
        this.SaborRecheio = SaborRecheio;
    }

    public String getTamanho() {
        return Tamanho;
    }

    public void setTamanho(String Tamanho) {
        this.Tamanho = Tamanho;
    }

    public String getSaborCasca() {
        return SaborCasca;
    }

    public void setSaborCasca(String SaborCasca) {
        this.SaborCasca = SaborCasca;
    }

    public float getValorProduto() {
        return ValorProduto;
    }

    public void setValorProduto(float ValorProduto) {
        this.ValorProduto = ValorProduto;
    }
     
    public int getIdPedido() {
        return IdPedido;
    }

    public void setIdPedido(int IdPedido) {
        this.IdPedido = IdPedido;
    }

    public String getDataEntrega() {
        return DataEntrega;
    }

    public void setDataEntrega(String DataEntrega) {
        this.DataEntrega = DataEntrega;
    }

    public float getValorTotal() {
        return ValorTotal;
    }

    public void setValorTotal(float ValorTotal) {
        this.ValorTotal = ValorTotal;
    }

    public int getIdcliente() {
        return Idcliente;
    }

    public void setIdcliente(int Idcliente) {
        this.Idcliente = Idcliente;
    }
    
}
