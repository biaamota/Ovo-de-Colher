package model;

import model.Login;

public class Vendedor {
    private int IdVendedor;
    private String NomeVedendor;
    private String DataNascimentoVedendor; 
    private int	TelefoneVedendor;
    private String Usuario;
    private String Senha;
    
    

     public Vendedor() {
    
}
    
    public Vendedor(String NomeVedendor, String DataNascimentoVedendor, int TelefoneVedendor, String Usuario,  String Senha) {
        this.NomeVedendor = NomeVedendor;
        this.DataNascimentoVedendor = DataNascimentoVedendor;
        this.TelefoneVedendor = TelefoneVedendor;
        this.Usuario = Usuario;
        this.Senha = Senha;
    }

    public Vendedor(String NomeVedendor, String Usuario, String Senha) {
           this.NomeVedendor = NomeVedendor;
           this.Usuario = Usuario;
           this.Senha = Senha;
    }
    
         public void cadastrarVendedor(Vendedor vend){
        
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    }

    
    public int getIdVendedor() {
        return IdVendedor;
    }

    public void setIdVendedor(int IdVendedor) {
        this.IdVendedor = IdVendedor;
    }

    public String getNomeVedendor() {
        return NomeVedendor;
    }

    public void setNomeVedendor(String NomeVedendor) {
        this.NomeVedendor = NomeVedendor;
    }

    public String getDataNascimentoVedendor() {
        return DataNascimentoVedendor;
    }

    public void setDataNascimentoVedendor(String DataNascimentoVedendor) {
        this.DataNascimentoVedendor = DataNascimentoVedendor;
    }

    public int getTelefoneVedendor() {
        return TelefoneVedendor;
    }

    public void setTelefoneVedendor(int TelefoneVedendor) {
        this.TelefoneVedendor = TelefoneVedendor;
    }

  
    
}
