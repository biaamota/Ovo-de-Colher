package model;

public class Cliente {
    
    private int Idcliente;
    private int TelefoneCliente;
    private int TipoCliente;
    private String NomeCliente;
    private String Rua;
    private int NumCasa;
    private String Bairro;
    private String CEP;
    private String UF;
    private String CPF_CNPJ;
    private String DataNascimentoCli;

    public Cliente(int TelefoneCliente, int TipoCliente, String NomeCliente, String Rua, int NumCasa, String Bairro, String CEP, String UF, String CPF_CNPJ, String DataNascimentoCli) {
       this.TelefoneCliente = TelefoneCliente;
       this.TipoCliente = TipoCliente;
       this.NomeCliente = NomeCliente;
       this.Rua = Rua;
       this.NumCasa = NumCasa;
       this.Bairro = Bairro;
       this.CEP = CEP;
       this.UF = UF;
       this.CPF_CNPJ = CPF_CNPJ;
       this.DataNascimentoCli = DataNascimentoCli;
       
    }

    public Cliente(String NomeCliente, int TelefoneCliente, int TipoCliente) {
        this.NomeCliente = NomeCliente;
        this.TelefoneCliente = TelefoneCliente;
        this.TipoCliente = TipoCliente;
        
    }

     public void cadastrarCliente(Cliente cliente){
        
    }

 
    public int getIdcliente() {
        return Idcliente;
    }

    public void setIdcliente(int Idcliente) {
        this.Idcliente = Idcliente;
    }

    public int getTelefoneCliente() {
        return TelefoneCliente;
    }

    public void setTelefoneCliente(int TelefoneCliente) {
        this.TelefoneCliente = TelefoneCliente;
    }

    public int getTipoCliente() {
        return TipoCliente;
    }

    public void setTipoCliente(int TipoCliente) {
        this.TipoCliente = TipoCliente;
    }

    public String getNomeCliente() {
        return NomeCliente;
    }

    public void setNomeCliente(String NomeCliente) {
        this.NomeCliente = NomeCliente;
    }

    public String getRua() {
        return Rua;
    }

    public void setRua(String Rua) {
        this.Rua = Rua;
    }

    public int getNumCasa() {
        return NumCasa;
    }

    public void setNumCasa(int NumCasa) {
        this.NumCasa = NumCasa;
    }

    public String getBairro() {
        return Bairro;
    }

    public void setBairro(String Bairro) {
        this.Bairro = Bairro;
    }

    public String getCEP() {
        return CEP;
    }

    public void setCEP(String CEP) {
        this.CEP = CEP;
    }

    public String getUF() {
        return UF;
    }

    public void setUF(String UF) {
        this.UF = UF;
    }

    public String getCPF_CNPJ() {
        return CPF_CNPJ;
    }

    public void setCPF_CNPJ(String CPF_CNPJ) {
        this.CPF_CNPJ = CPF_CNPJ;
    }

    public String getDataNascimentoCli() {
        return DataNascimentoCli;
    }

    public void setDataNascimentoCli(String DataNascimentoCli) {
        this.DataNascimentoCli = DataNascimentoCli;
    }

      
}
