
package model;

public class Login {
    private String Usuario;
    private String Senha;
    private static String usuarioAltentica;
    private static int IdLoginVendedor;

    public static int getIdLoginVendedor() {
        return IdLoginVendedor;
    }

    public static void setIdLoginVendedor(int IdLoginVendedor) {
        Login.IdLoginVendedor = IdLoginVendedor;
    }

    public static String getUsuarioAltentica() {
        return usuarioAltentica;
    }

    public static void setUsuarioAltentica(String usuarioAltentica) {
        Login.usuarioAltentica = usuarioAltentica;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    }

    public void setVisible(boolean b) {
         }
    
    
}
