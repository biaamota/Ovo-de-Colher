
package model;

public class Login {
    private String Usuario;
    private String Senha;

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    }

    public void setVisible(boolean b) {
         }
    
    
}
